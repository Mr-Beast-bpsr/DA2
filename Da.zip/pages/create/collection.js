import React from 'react'
import CreateCollection from '../../components/Create/CreateCollection'

const createcollection = () => {
  return (
    <CreateCollection/>
  )
}

export default createcollection