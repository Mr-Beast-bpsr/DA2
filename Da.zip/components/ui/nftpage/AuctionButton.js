import React from 'react'

const AuctionButton = () => {
  return (
    <div>AuctionButton</div>
  )
}

export default AuctionButton