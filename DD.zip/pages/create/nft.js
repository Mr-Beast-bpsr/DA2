
import React from 'react'
import CreateNFT from '../../components/Create/CreateNFT'

const nft = () => {
  return (
      <CreateNFT/>
  
  )
}

export default nft;