// import React,{useEffect} from 'react'
// import { useContractWrite  , useWaitForTransaction} from 'wagmi'
// import ab from "../../public/abi/DaFactory.json";
// import ab2 from "../../public/abi/DaAuction.json";
// const { abi2 } = ab2;
// const { abi } = ab;
// function Wagmi({quantity}) {

   
//     useEffect(()=>{

//         console.log(isError, isLoading, data)
//     },[data, isError, isLoading])
//   console.log(quantity)
//     return <button onClick={() => write({args:[parseInt(quantity)]})}>Feed</button>
//   }

// export default Wagmi;